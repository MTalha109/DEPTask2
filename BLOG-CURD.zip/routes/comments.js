const express = require('express');
const router = express.Router();
const { createComment, getAllComments } = require('../controllers/commentController');

router.post('/', createComment);
router.get('/', getAllComments);

module.exports = router;